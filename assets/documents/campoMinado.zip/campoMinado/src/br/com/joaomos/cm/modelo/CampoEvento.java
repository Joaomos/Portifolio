package br.com.joaomos.cm.modelo;

public enum CampoEvento {
	ABRIR, MARCAR, DESMARCAR, EXPLODIR, REINICIAR
}
