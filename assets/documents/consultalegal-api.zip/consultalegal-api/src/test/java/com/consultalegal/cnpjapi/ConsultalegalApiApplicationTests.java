package com.consultalegal.cnpjapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultalegalApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
